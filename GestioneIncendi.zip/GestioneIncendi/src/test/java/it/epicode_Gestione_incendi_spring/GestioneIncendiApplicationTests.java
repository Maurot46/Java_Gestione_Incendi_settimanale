package it.epicode_Gestione_incendi_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestioneIncendiApplicationTests {

	@Test
	void contextLoads() {
	}

}
