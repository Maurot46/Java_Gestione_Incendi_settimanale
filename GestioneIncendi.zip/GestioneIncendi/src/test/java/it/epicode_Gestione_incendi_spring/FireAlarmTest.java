package it.epicode_Gestione_incendi_spring;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import it.epicode_Gestione_incendi_spring.ProxyPattern.AlarmNotifier;
import it.epicode_Gestione_incendi_spring.ProxyPattern.Sonda;

class FireAlarmTest {
	@Test
    public void testGetters() {
        Sonda sonda = new Sonda(1, 45.464, 9.191, 5, new MockAlarmNotifier());
        assertEquals(1, sonda.getId());
        assertEquals(45.464, sonda.getLatitude(), 0.001);
        assertEquals(9.191, sonda.getLongitude(), 0.001);
        assertEquals(5, sonda.getSmokeLevel());
    }
	@Test
    public void testNotifyAlarm() {
        MockAlarmNotifier mockNotifier = new MockAlarmNotifier();
        Sonda sonda = new Sonda(1, 45.464, 9.191, 5, mockNotifier);
        sonda.notifyAlarm();
        assertEquals("idsonda=1&lat=45.464&lon=9.191&smokelevel=5", mockNotifier.getLastNotifiedData());
    }
    
    private static class MockAlarmNotifier implements AlarmNotifier {

        private String lastNotifiedData;
        
        @Override
        public void notify(String data) {
            lastNotifiedData = data;
        }
        
        public String getLastNotifiedData() {
            return lastNotifiedData;
        }
        
    }
	    

}
