package it.epicode_Gestione_incendi_spring;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import it.epicode_Gestione_incendi_spring.ProxyPattern.AlarmNotifier;
import it.epicode_Gestione_incendi_spring.ProxyPattern.HttpAlarmNotifierProxy;
import it.epicode_Gestione_incendi_spring.ProxyPattern.Sonda;

@SpringBootApplication
public class GestioneIncendiApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(GestioneIncendiApplication.class, args);
		
	}

	@Override
	public void run(String... args) throws Exception {
		 AlarmNotifier notifier = new HttpAlarmNotifierProxy("http://host/alarm");
		    Sonda sonda1 = new Sonda(1, 45.4641, 9.1919, 3, notifier);
		    Sonda sonda2 = new Sonda(2, 42.3314, -83.0458, 6, notifier);
		    System.out.println("Sonda 1");
		    sonda1.notifyAlarm();
		    System.out.println("Sonda 2");
		    sonda2.notifyAlarm();
    }


}
