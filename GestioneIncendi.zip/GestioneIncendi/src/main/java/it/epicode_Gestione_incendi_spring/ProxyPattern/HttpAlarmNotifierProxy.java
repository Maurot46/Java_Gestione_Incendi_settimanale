package it.epicode_Gestione_incendi_spring.ProxyPattern;

public class HttpAlarmNotifierProxy implements AlarmNotifier{
	private final String url;

    public HttpAlarmNotifierProxy(String url) {
        this.url = url;
    }

    @Override
    public void notify(String data) {
        // Here we would make an HTTP request to the actual server
        // but for this example we will just print the URL to the console
        System.out.println(url + "?" + data);
    }
}
