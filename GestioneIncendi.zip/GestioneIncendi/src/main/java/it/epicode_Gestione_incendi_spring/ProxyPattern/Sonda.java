package it.epicode_Gestione_incendi_spring.ProxyPattern;

public class Sonda {
	private final long id;
    private final double latitude;
    private final double longitude;
    private final int smokeLevel;
    private final AlarmNotifier notifier;

    public Sonda(long id, double latitude, double longitude, int smokeLevel, AlarmNotifier notifier) {
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.smokeLevel = smokeLevel;
        this.notifier = notifier;
    }

    public long getId() {
        return id;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getSmokeLevel() {
        return smokeLevel;
    }

    public void notifyAlarm() {
        String data = "idsonda=" + id + "&lat=" + latitude + "&lon=" + longitude + "&smokelevel=" + smokeLevel;
        notifier.notify(data);
    }
}
