package it.epicode_Gestione_incendi_spring.ProxyPattern;

public interface AlarmNotifier {
	void notify(String data);
}
